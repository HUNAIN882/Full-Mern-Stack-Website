"use client"

import { useEffect, useState } from "react"
import type { Product } from "@/lib/product"
import { ProductCard } from "@/components/product-card"
import { getCart } from "@/lib/cart" // Import getCart

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [cartItemCount, setCartItemCount] = useState(0) // State for cart item count

  useEffect(() => {
    async function fetchProducts() {
      try {
        const response = await fetch("/api/products")
        if (!response.ok) {
          throw new Error("Failed to fetch products")
        }
        const data: Product[] = await response.json()
        setProducts(data)
      } catch (err: any) {
        setError(err.message)
      } finally {
        setLoading(false)
      }
    }
    fetchProducts()
    setCartItemCount(getCart().reduce((total, item) => total + item.quantity, 0)) // Initialize cart count
  }, [])

  const handleAddToCart = () => {
    // Handler to update cart count
    setCartItemCount(getCart().reduce((total, item) => total + item.quantity, 0))
  }

  if (loading) {
    return <div className="flex min-h-[calc(100vh-64px)] items-center justify-center">Loading products...</div>
  }

  if (error) {
    return <div className="flex min-h-[calc(100vh-64px)] items-center justify-center text-red-500">Error: {error}</div>
  }

  return (
    <main className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-center mb-8">Our Products</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} onAddToCart={handleAddToCart} /> // Pass onAddToCart
        ))}
      </div>
    </main>
  )
}
