"use client"

import { useEffect, useState } from "react"
import { useParams } from "next/navigation"
import Image from "next/image"
import type { Product } from "@/lib/product"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { addToCart } from "@/lib/cart" // Import addToCart
import { useRouter } from "next/navigation" // Import useRouter

export default function ProductDetailsPage() {
  const { id } = useParams()
  const [product, setProduct] = useState<Product | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter() // Initialize useRouter

  useEffect(() => {
    if (id) {
      async function fetchProduct() {
        try {
          const response = await fetch(`/api/products/${id}`)
          if (!response.ok) {
            throw new Error("Failed to fetch product")
          }
          const data: Product = await response.json()
          setProduct(data)
        } catch (err: any) {
          setError(err.message)
        } finally {
          setLoading(false)
        }
      }
      fetchProduct()
    }
  }, [id])

  const handleAddToCart = () => {
    // Add to cart handler
    if (product) {
      addToCart(product)
      router.push("/cart") // Redirect to cart page after adding
    }
  }

  if (loading) {
    return <div className="flex min-h-[calc(100vh-64px)] items-center justify-center">Loading product details...</div>
  }

  if (error) {
    return <div className="flex min-h-[calc(100vh-64px)] items-center justify-center text-red-500">Error: {error}</div>
  }

  if (!product) {
    return <div className="flex min-h-[calc(100vh-64px)] items-center justify-center">Product not found.</div>
  }

  return (
    <main className="container mx-auto px-4 py-8">
      <Card className="flex flex-col md:flex-row gap-8 p-6">
        <div className="md:w-1/2">
          <Image
            src={product.imageUrl || "/placeholder.svg"}
            alt={product.name}
            width={600}
            height={400}
            className="w-full h-auto object-cover rounded-lg"
          />
        </div>
        <div className="md:w-1/2 flex flex-col justify-center">
          <CardHeader className="px-0 pt-0">
            <CardTitle className="text-4xl font-bold">{product.name}</CardTitle>
            <CardDescription className="text-lg text-muted-foreground mt-2">{product.description}</CardDescription>
          </CardHeader>
          <CardContent className="px-0 flex-grow">
            <p className="text-3xl font-extrabold mt-4">${product.price.toFixed(2)}</p>
            <div className="mt-6">
              <Button size="lg" className="w-full md:w-auto" onClick={handleAddToCart}>
                {" "}
                {/* Add onClick handler */}
                Add to Cart
              </Button>
            </div>
          </CardContent>
        </div>
      </Card>
    </main>
  )
}
