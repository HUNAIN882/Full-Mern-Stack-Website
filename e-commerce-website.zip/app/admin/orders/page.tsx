"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { getSession } from "@/lib/auth"
import { isAdmin } from "@/lib/admin"
import { AdminOrderList } from "@/components/admin-order-list"

export default function AdminOrdersPage() {
  const [user, setUser] = useState<{ id: string; email: string } | null>(null)
  const router = useRouter()

  useEffect(() => {
    const currentUser = getSession()
    setUser(currentUser)
    if (!currentUser || !isAdmin(currentUser.email)) {
      router.push("/login") // Redirect non-admin users
    }
  }, [router])

  if (!user || !isAdmin(user.email)) {
    return (
      <div className="flex min-h-[calc(100vh-64px)] items-center justify-center">Access Denied. Redirecting...</div>
    )
  }

  return (
    <main className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-center mb-8">Order Management</h1>
      <AdminOrderList />
    </main>
  )
}
