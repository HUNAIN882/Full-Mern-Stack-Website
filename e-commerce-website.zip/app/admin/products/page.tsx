"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { getSession } from "@/lib/auth"
import { isAdmin } from "@/lib/admin"
import { AdminProductList } from "@/components/admin-product-list"

export default function AdminProductsPage() {
  const [user, setUser] = useState<{ id: string; email: string } | null>(null)
  const router = useRouter()

  useEffect(() => {
    const currentUser = getSession()
    setUser(currentUser)
    if (!currentUser || !isAdmin(currentUser.email)) {
      router.push("/login") // Redirect non-admin users
    }
  }, [router])

  if (!user || !isAdmin(user.email)) {
    return (
      <div className="flex min-h-[calc(100vh-64px)] items-center justify-center">Access Denied. Redirecting...</div>
    )
  }

  const handleProductChange = () => {
    // This function can be used to trigger a re-fetch or state update in parent components if needed
    console.log("[v0] Product list updated, refreshing...")
  }

  return (
    <main className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-center mb-8">Product Management</h1>
      <AdminProductList onProductChange={handleProductChange} />
    </main>
  )
}
