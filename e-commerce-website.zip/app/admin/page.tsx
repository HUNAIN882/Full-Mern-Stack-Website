"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { getSession } from "@/lib/auth"
import { isAdmin } from "@/lib/admin"
import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export default function AdminDashboardPage() {
  const [user, setUser] = useState<{ id: string; email: string } | null>(null)
  const router = useRouter()

  useEffect(() => {
    const currentUser = getSession()
    setUser(currentUser)
    if (!currentUser || !isAdmin(currentUser.email)) {
      router.push("/login") // Redirect non-admin users
    }
  }, [router])

  if (!user || !isAdmin(user.email)) {
    return (
      <div className="flex min-h-[calc(100vh-64px)] items-center justify-center">Access Denied. Redirecting...</div>
    )
  }

  return (
    <main className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-center mb-8">Admin Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Link href="/admin/products">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader>
              <CardTitle>Product Management</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">Add, edit, and delete products.</p>
              <Button className="mt-4">Go to Products</Button>
            </CardContent>
          </Card>
        </Link>
        <Link href="/admin/orders">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader>
              <CardTitle>Order Management</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">View and update customer orders.</p>
              <Button className="mt-4">Go to Orders</Button>
            </CardContent>
          </Card>
        </Link>
      </div>
    </main>
  )
}
