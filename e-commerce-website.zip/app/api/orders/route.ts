import { NextResponse } from "next/server"
import { orders, type Order } from "@/lib/order"
import { getSession } from "@/lib/auth" // Assuming getSession can be used server-side for mock purposes

export async function POST(request: Request) {
  const session = getSession() // Mock session check
  if (!session || !session.id) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
  }

  const { items, totalAmount, shippingAddress } = await request.json()

  if (!items || items.length === 0 || !totalAmount || !shippingAddress) {
    return NextResponse.json({ message: "Missing order details" }, { status: 400 })
  }

  const newOrder: Order = {
    id: String(orders.length + 1),
    userId: session.id,
    items,
    totalAmount,
    shippingAddress,
    status: "pending",
    createdAt: new Date().toISOString(),
  }
  orders.push(newOrder)

  return NextResponse.json({ message: "Order placed successfully", order: newOrder }, { status: 201 })
}

export async function GET(request: Request) {
  const session = getSession() // Mock session check
  if (!session || !session.id) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
  }

  const userOrders = orders.filter((order) => order.userId === session.id)
  return NextResponse.json(userOrders)
}
