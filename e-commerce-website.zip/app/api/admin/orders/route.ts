import { NextResponse } from "next/server"
import { orders } from "@/lib/order"
import { getSession } from "@/lib/auth"
import { isAdmin } from "@/lib/admin"

// Helper to check admin status
const checkAdmin = () => {
  const session = getSession()
  if (!session || !isAdmin(session.email)) {
    return NextResponse.json({ message: "Unauthorized: Admin access required" }, { status: 403 })
  }
  return null
}

export async function GET() {
  const authError = checkAdmin()
  if (authError) return authError
  return NextResponse.json(orders)
}

export async function PUT(request: Request) {
  const authError = checkAdmin()
  if (authError) return authError

  const { id, status } = await request.json()
  const order = orders.find((o) => o.id === id)

  if (!order) {
    return NextResponse.json({ message: "Order not found" }, { status: 404 })
  }

  order.status = status
  return NextResponse.json(order)
}
