import { NextResponse } from "next/server"
import { products, type Product } from "@/lib/product"
import { getSession } from "@/lib/auth"
import { isAdmin } from "@/lib/admin"

// Helper to check admin status
const checkAdmin = () => {
  const session = getSession()
  if (!session || !isAdmin(session.email)) {
    return NextResponse.json({ message: "Unauthorized: Admin access required" }, { status: 403 })
  }
  return null
}

export async function GET() {
  const authError = checkAdmin()
  if (authError) return authError
  return NextResponse.json(products)
}

export async function POST(request: Request) {
  const authError = checkAdmin()
  if (authError) return authError

  const newProduct: Product = await request.json()
  if (!newProduct.name || !newProduct.price || !newProduct.description || !newProduct.imageUrl) {
    return NextResponse.json({ message: "Missing product details" }, { status: 400 })
  }

  newProduct.id = String(products.length + 1)
  products.push(newProduct)
  return NextResponse.json(newProduct, { status: 201 })
}

export async function PUT(request: Request) {
  const authError = checkAdmin()
  if (authError) return authError

  const updatedProduct: Product = await request.json()
  const index = products.findIndex((p) => p.id === updatedProduct.id)

  if (index === -1) {
    return NextResponse.json({ message: "Product not found" }, { status: 404 })
  }

  products[index] = { ...products[index], ...updatedProduct }
  return NextResponse.json(products[index])
}

export async function DELETE(request: Request) {
  const authError = checkAdmin()
  if (authError) return authError

  const { id } = await request.json()
  const initialLength = products.length
  const newProducts = products.filter((p) => p.id !== id)

  if (newProducts.length === initialLength) {
    return NextResponse.json({ message: "Product not found" }, { status: 404 })
  }

  // Clear the original array and push filtered items
  products.length = 0
  products.push(...newProducts)

  return NextResponse.json({ message: "Product deleted successfully" })
}
