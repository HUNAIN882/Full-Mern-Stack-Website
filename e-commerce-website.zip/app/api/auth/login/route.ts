import { NextResponse } from "next/server"
import { users } from "@/lib/user"

export async function POST(request: Request) {
  const { email, password } = await request.json()

  if (!email || !password) {
    return NextResponse.json({ message: "Email and password are required" }, { status: 400 })
  }

  const user = users.find((u) => u.email === email && u.password === password) // In a real app, compare hashed passwords

  if (!user) {
    return NextResponse.json({ message: "Invalid credentials" }, { status: 401 })
  }

  // In a real app, you would generate and return a JWT or session token
  return NextResponse.json({ message: "Login successful", user: { id: user.id, email: user.email } }, { status: 200 })
}
