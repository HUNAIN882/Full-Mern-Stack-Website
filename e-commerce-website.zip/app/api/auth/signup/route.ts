import { NextResponse } from "next/server"
import { users, type User } from "@/lib/user"

export async function POST(request: Request) {
  const { email, password } = await request.json()

  if (!email || !password) {
    return NextResponse.json({ message: "Email and password are required" }, { status: 400 })
  }

  if (users.some((user) => user.email === email)) {
    return NextResponse.json({ message: "User with this email already exists" }, { status: 409 })
  }

  const newUser: User = {
    id: String(users.length + 1),
    email,
    password, // In a real app, hash this password
  }
  users.push(newUser)

  return NextResponse.json(
    { message: "User registered successfully", user: { id: newUser.id, email: newUser.email } },
    { status: 201 },
  )
}
