"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { getSession } from "@/lib/auth"
import type { Order } from "@/lib/order"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const user = getSession()

  useEffect(() => {
    async function fetchOrders() {
      if (!user) {
        setError("You must be logged in to view orders.")
        setLoading(false)
        return
      }
      try {
        const response = await fetch("/api/orders")
        if (!response.ok) {
          throw new Error("Failed to fetch orders")
        }
        const data: Order[] = await response.json()
        setOrders(data)
      } catch (err: any) {
        setError(err.message)
      } finally {
        setLoading(false)
      }
    }
    fetchOrders()
  }, [user])

  if (loading) {
    return <div className="flex min-h-[calc(100vh-64px)] items-center justify-center">Loading orders...</div>
  }

  if (error) {
    return <div className="flex min-h-[calc(100vh-64px)] items-center justify-center text-red-500">Error: {error}</div>
  }

  if (orders.length === 0) {
    return (
      <main className="flex min-h-[calc(100vh-64px)] flex-col items-center justify-center p-24">
        <h1 className="text-3xl font-bold mb-4">No Orders Found</h1>
        <p className="text-lg text-muted-foreground mb-8">You haven't placed any orders yet.</p>
        <Link href="/products">
          <Button size="lg">Start Shopping</Button>
        </Link>
      </main>
    )
  }

  return (
    <main className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-center mb-8">Your Orders</h1>
      <div className="space-y-6">
        {orders.map((order) => (
          <Card key={order.id}>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-xl">Order #{order.id}</CardTitle>
              <span
                className={`px-3 py-1 rounded-full text-sm font-medium ${
                  order.status === "completed"
                    ? "bg-green-100 text-green-800"
                    : order.status === "pending"
                      ? "bg-yellow-100 text-yellow-800"
                      : "bg-red-100 text-red-800"
                }`}
              >
                {order.status}
              </span>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-2">Placed on: {new Date(order.createdAt).toLocaleDateString()}</p>
              <p className="font-semibold mb-2">Total: ${order.totalAmount.toFixed(2)}</p>
              <h3 className="text-lg font-semibold mb-2">Items:</h3>
              <ul className="list-disc pl-5 space-y-1">
                {order.items.map((item) => (
                  <li key={item.id}>
                    {item.name} (x{item.quantity}) - ${item.price.toFixed(2)} each
                  </li>
                ))}
              </ul>
              <h3 className="text-lg font-semibold mt-4 mb-2">Shipping Address:</h3>
              <p>{order.shippingAddress.fullName}</p>
              <p>{order.shippingAddress.address}</p>
              <p>
                {order.shippingAddress.city}, {order.shippingAddress.postalCode}
              </p>
              <p>{order.shippingAddress.country}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </main>
  )
}
