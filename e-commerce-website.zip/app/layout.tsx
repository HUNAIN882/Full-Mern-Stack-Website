import type React from "react"
import type { Metadata } from "next"
import { GeistSans } from "geist/font/sans"
import { Analytics } from "@vercel/analytics/next"
import { Header } from "@/components/header" // Import the Header component
import { Suspense } from "react" // Import Suspense
import "./globals.css"

export const metadata: Metadata = {
  title: "v0 App",
  description: "Created with v0",
  generator: "v0.app",
}

const geistSans = GeistSans

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${geistSans.variable} antialiased`}>
      <body>
        <Suspense fallback={<div>Loading...</div>}>
          {" "}
          {/* Wrap components in Suspense boundary */}
          <Header /> {/* Add the Header component */}
          {children}
          <Analytics />
        </Suspense>
      </body>
    </html>
  )
}
