"use client"

import { useEffect, useState } from "react"
import { getSession } from "@/lib/auth"
import Link from "next/link"
import Button from "@/components/Button" // Assuming Button component is imported from a local path

export default function HomePage() {
  const [user, setUser] = useState<{ id: string; email: string } | null>(null)

  useEffect(() => {
    setUser(getSession())
  }, [])

  return (
    <main className="flex min-h-[calc(100vh-64px)] flex-col items-center justify-center p-24">
      <h1 className="text-4xl font-bold text-center">
        {user ? `Welcome back, ${user.email}!` : "Welcome to our E-Commerce Store!"}
      </h1>
      <p className="mt-4 text-lg text-center">
        {user ? "Start exploring our amazing products." : "Please login or sign up to continue."}
      </p>
      <div className="mt-8">
        <Link href="/products">
          <Button size="lg">View Products</Button>
        </Link>
      </div>
    </main>
  )
}
