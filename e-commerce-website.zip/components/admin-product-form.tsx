"use client"

import type React from "react"

import { useState, useEffect } from "react"
import type { Product } from "@/lib/product"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface AdminProductFormProps {
  product?: Product // Optional product for editing
  onSave: () => void
}

export function AdminProductForm({ product, onSave }: AdminProductFormProps) {
  const [name, setName] = useState(product?.name || "")
  const [description, setDescription] = useState(product?.description || "")
  const [price, setPrice] = useState(product?.price.toString() || "")
  const [imageUrl, setImageUrl] = useState(product?.imageUrl || "")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (product) {
      setName(product.name)
      setDescription(product.description)
      setPrice(product.price.toString())
      setImageUrl(product.imageUrl)
    } else {
      setName("")
      setDescription("")
      setPrice("")
      setImageUrl("")
    }
  }, [product])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setLoading(true)

    const productData = {
      id: product?.id,
      name,
      description,
      price: Number.parseFloat(price),
      imageUrl,
    }

    const endpoint = product ? "/api/admin/products" : "/api/admin/products"
    const method = product ? "PUT" : "POST"

    try {
      const response = await fetch(endpoint, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(productData),
      })

      const data = await response.json()

      if (!response.ok) {
        setError(data.message || "Failed to save product")
        return
      }

      console.log("[v0] Product saved successfully:", data)
      onSave() // Callback to refresh product list
      if (!product) {
        // Clear form for new product
        setName("")
        setDescription("")
        setPrice("")
        setImageUrl("")
      }
    } catch (err: any) {
      console.error("[v0] Product save error:", err)
      setError("Network error or server is unreachable")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>{product ? "Edit Product" : "Add New Product"}</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="grid gap-4">
          <div className="grid gap-2">
            <Label htmlFor="name">Product Name</Label>
            <Input id="name" type="text" required value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="description">Description</Label>
            <Textarea id="description" required value={description} onChange={(e) => setDescription(e.target.value)} />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="price">Price</Label>
            <Input
              id="price"
              type="number"
              step="0.01"
              required
              value={price}
              onChange={(e) => setPrice(e.target.value)}
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="imageUrl">Image URL</Label>
            <Input id="imageUrl" type="url" required value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} />
          </div>
          {error && <p className="text-red-500 text-sm text-center">{error}</p>}
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? "Saving..." : product ? "Update Product" : "Add Product"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
