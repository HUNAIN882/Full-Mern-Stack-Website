"use client"

import Link from "next/link"
import Image from "next/image"
import type { Product } from "@/lib/product"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { addToCart } from "@/lib/cart" // Import addToCart

interface ProductCardProps {
  product: Product
  onAddToCart?: (product: Product) => void // Add optional onAddToCart prop
}

export function ProductCard({ product, onAddToCart }: ProductCardProps) {
  // Destructure onAddToCart
  const handleAddToCart = () => {
    addToCart(product)
    if (onAddToCart) {
      onAddToCart(product)
    }
  }

  return (
    <Card className="flex flex-col justify-between h-full">
      <CardHeader>
        <Image
          src={product.imageUrl || "/placeholder.svg"}
          alt={product.name}
          width={300}
          height={200}
          className="w-full h-48 object-cover rounded-t-lg"
        />
      </CardHeader>
      <CardContent className="flex-grow">
        <CardTitle className="text-lg font-semibold">{product.name}</CardTitle>
        <p className="text-sm text-muted-foreground mt-2 line-clamp-2">{product.description}</p>
        <p className="text-xl font-bold mt-4">${product.price.toFixed(2)}</p>
      </CardContent>
      <CardFooter className="flex justify-between items-center">
        <Link href={`/products/${product.id}`}>
          <Button variant="outline" size="sm">
            View Details
          </Button>
        </Link>
        <Button size="sm" onClick={handleAddToCart}>
          {" "}
          {/* Add onClick handler */}
          Add to Cart
        </Button>
      </CardFooter>
    </Card>
  )
}
