import type React from "react"
import { Button as ShadcnButton, type ButtonProps } from "@/components/ui/button"

interface CustomButtonProps extends ButtonProps {
  // Add any custom props here if needed
}

const Button: React.FC<CustomButtonProps> = ({ children, ...props }) => {
  return <ShadcnButton {...props}>{children}</ShadcnButton>
}

export default Button
