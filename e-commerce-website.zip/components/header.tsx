"use client"

import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { getSession, clearSession } from "@/lib/auth"
import { isAdmin } from "@/lib/admin" // Import isAdmin
import { useEffect, useState } from "react"
import { ShoppingCart } from "lucide-react"
import { getCart } from "@/lib/cart"

export function Header() {
  const [user, setUser] = useState<{ id: string; email: string } | null>(null)
  const [cartItemCount, setCartItemCount] = useState(0)
  const router = useRouter()

  useEffect(() => {
    const currentUser = getSession()
    setUser(currentUser)
    setCartItemCount(getCart().reduce((total, item) => total + item.quantity, 0))
  }, [])

  const updateCartCount = () => {
    setCartItemCount(getCart().reduce((total, item) => total + item.quantity, 0))
  }

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" })
    clearSession()
    setUser(null)
    setCartItemCount(0)
    router.push("/login")
  }

  return (
    <header className="bg-primary text-primary-foreground p-4 flex justify-between items-center">
      <Link href="/" className="text-xl font-bold">
        E-Commerce
      </Link>
      <nav className="flex items-center space-x-4">
        <Link href="/products">
          <Button variant="ghost" size="sm">
            Products
          </Button>
        </Link>
        {user && (
          <Link href="/orders">
            <Button variant="ghost" size="sm">
              Orders
            </Button>
          </Link>
        )}
        {user &&
          isAdmin(user.email) && ( // Show Admin link only if user is admin
            <Link href="/admin">
              <Button variant="ghost" size="sm">
                Admin
              </Button>
            </Link>
          )}
        <Link href="/cart" className="relative">
          <Button variant="ghost" size="icon">
            <ShoppingCart className="h-5 w-5" />
            {cartItemCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-accent text-accent-foreground rounded-full h-4 w-4 flex items-center justify-center text-xs">
                {cartItemCount}
              </span>
            )}
          </Button>
        </Link>
        {user ? (
          <>
            <span className="hidden md:inline">Welcome, {user.email}</span>
            <Button onClick={handleLogout} variant="secondary" size="sm">
              Logout
            </Button>
          </>
        ) : (
          <>
            <Link href="/login">
              <Button variant="secondary" size="sm">
                Login
              </Button>
            </Link>
            <Link href="/signup">
              <Button variant="secondary" size="sm">
                Sign Up
              </Button>
            </Link>
          </>
        )}
      </nav>
    </header>
  )
}
