export const isAdmin = (email: string | undefined): boolean => {
  return email === "admin@example.com"
}
