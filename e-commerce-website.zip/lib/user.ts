export interface User {
  id: string
  email: string
  password: string // In a real app, this would be hashed
}

// Mock in-memory user store
export const users: User[] = []
