export interface Product {
  id: string
  name: string
  description: string
  price: number
  imageUrl: string
}

export const products: Product[] = [
  {
    id: "1",
    name: "Stylish T-Shirt",
    description: "A comfortable and stylish t-shirt made from 100% organic cotton.",
    price: 25.0,
    imageUrl: "/stylish-t-shirt.jpg",
  },
  {
    id: "2",
    name: "Classic Jeans",
    description: "Durable and fashionable jeans, perfect for everyday wear.",
    price: 55.0,
    imageUrl: "/classic-jeans.jpg",
  },
  {
    id: "3",
    name: "Running Shoes",
    description: "Lightweight and supportive running shoes for your daily jog.",
    price: 80.0,
    imageUrl: "/running-shoes.jpg",
  },
  {
    id: "4",
    name: "Leather Wallet",
    description: "A sleek and functional leather wallet with multiple card slots.",
    price: 40.0,
    imageUrl: "/leather-wallet.jpg",
  },
  {
    id: "5",
    name: "Wireless Headphones",
    description: "High-quality wireless headphones with noise-cancelling features.",
    price: 120.0,
    imageUrl: "/wireless-headphones.jpg",
  },
  {
    id: "6",
    name: "Smartwatch",
    description: "A feature-rich smartwatch to track your fitness and notifications.",
    price: 150.0,
    imageUrl: "/smartwatch.jpg",
  },
  {
    id: "7",
    name: "Backpack",
    description: "A durable and spacious backpack for travel or daily use.",
    price: 70.0,
    imageUrl: "/backpack.jpg",
  },
  {
    id: "8",
    name: "Sunglasses",
    description: "Stylish sunglasses with UV protection.",
    price: 30.0,
    imageUrl: "/sunglasses.jpg",
  },
  {
    id: "9",
    name: "Boy's Graphic Tee",
    description: "A fun graphic t-shirt for boys, made with soft cotton.",
    price: 18.0,
    imageUrl: "/boys-graphic-tee.jpg",
  },
  {
    id: "10",
    name: "Girl's Floral Dress",
    description: "A beautiful floral dress for girls, perfect for any occasion.",
    price: 35.0,
    imageUrl: "/girls-floral-dress.jpg",
  },
  {
    id: "11",
    name: "Building Blocks Set",
    description: "A large set of colorful building blocks for creative play.",
    price: 45.0,
    imageUrl: "/building-blocks-set.jpg",
  },
  {
    id: "12",
    name: "Remote Control Car",
    description: "A high-speed remote control car for endless fun.",
    price: 60.0,
    imageUrl: "/remote-control-car.jpg",
  },
  {
    id: "13",
    name: "Dollhouse",
    description: "A charming dollhouse with multiple rooms and furniture.",
    price: 90.0,
    imageUrl: "/dollhouse.jpg",
  },
  {
    id: "14",
    name: "Action Figure",
    description: "A collectible action figure with movable parts.",
    price: 22.0,
    imageUrl: "/action-figure.jpg",
  },
]
