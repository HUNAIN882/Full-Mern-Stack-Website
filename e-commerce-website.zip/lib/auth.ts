export const setSession = (user: { id: string; email: string }) => {
  localStorage.setItem("user", JSON.stringify(user))
}

export const getSession = () => {
  if (typeof window === "undefined") return null // Ensure this runs only on client-side
  const user = localStorage.getItem("user")
  return user ? JSON.parse(user) : null
}

export const clearSession = () => {
  localStorage.removeItem("user")
}
