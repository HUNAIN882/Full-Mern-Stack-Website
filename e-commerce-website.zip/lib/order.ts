import type { CartItem } from "./cart"

export interface OrderItem extends CartItem {}

export interface Order {
  id: string
  userId: string
  items: OrderItem[]
  totalAmount: number
  shippingAddress: {
    fullName: string
    address: string
    city: string
    postalCode: string
    country: string
  }
  status: "pending" | "completed" | "cancelled"
  createdAt: string
}

// Mock in-memory order store
export const orders: Order[] = []
